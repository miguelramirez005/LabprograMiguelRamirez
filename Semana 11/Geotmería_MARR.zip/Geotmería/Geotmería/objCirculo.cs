﻿namespace Geotmería
{
    internal class objCirculo
    {
    }
}